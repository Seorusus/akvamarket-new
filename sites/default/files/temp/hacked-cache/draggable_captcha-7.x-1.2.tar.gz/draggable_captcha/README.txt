Readme file for the Draggable CAPTCHA module
---------------------------------------------
Draggable captcha uses a lib from 
http://blog.lukeblackamore.com, which is free to use 
but not available any more. 

This module improves security and keeps maintenance.
This module is an integration of the captcha module, 
offering a draggable & clickable style of captcha.

Installation:
Install as usual modules.
