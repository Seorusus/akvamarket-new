<?php

/**
 * @file
 * Template to display jquery tab contents.
 */
?>
<div id="tabs-<?php print $variables['suffix'];?>-<?php print $variables['counter'];?>">
  <?php print $variables['tab_body']; ?>
</div>
