<?php

/**
 * @file
 * Template to display jquery tab list.
 */
?>
<li><a href="#tabs-<?php print $variables['suffix'];?>-<?php print $variables['counter'];?>"><?php print $variables['tab_title']; ?></a></li>
