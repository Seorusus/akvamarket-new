
View reference README

CONTENTS OF THIS FILE
----------------------

  * Introduction
  * Installation
  * Usage


INTRODUCTION
------------
Defines a field type View reference which creates a relationship to a Views 
display and allows the view to be displayed as the content of the field.

Project page: http://drupal.org/project/viewereference.


INSTALLATION
------------
Install and enable the View reference module.
For detailed instructions on installing contributed modules see:
http://drupal.org/documentation/install/modules-themes/modules-7


USAGE
-----
View reference fields will now be available in the Field UI.
For detailed instructions on using the Field UI see:
http://drupal.org/documentation/modules/field-ui