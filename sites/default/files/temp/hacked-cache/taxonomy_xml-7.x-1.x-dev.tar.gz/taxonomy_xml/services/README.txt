In here are small definition files that publish available taxonomy server 
services, and the utility we should use to make requests on them.
A taxonomy service should declare a function named after its file in a hook-like
syntax that tells the UI how this service should be accessed. 